-- Create admin users table
CREATE TABLE IF NOT EXISTS admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create paintings table
CREATE TABLE IF NOT EXISTS paintings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  image_url TEXT NOT NULL,
  category TEXT DEFAULT 'painting',
  width DECIMAL(5, 2),
  height DECIMAL(5, 2),
  medium TEXT,
  year INTEGER,
  stock INTEGER DEFAULT 1,
  featured BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT UNIQUE NOT NULL,
  customer_email TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT,
  total_price DECIMAL(10, 2) NOT NULL,
  status TEXT DEFAULT 'pending', -- pending, completed, shipped, delivered, cancelled
  stripe_payment_id TEXT,
  shipping_address TEXT,
  shipping_city TEXT,
  shipping_state TEXT,
  shipping_zip TEXT,
  shipping_country TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create order items table
CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  painting_id UUID NOT NULL REFERENCES paintings(id),
  quantity INTEGER DEFAULT 1,
  price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create newsletter subscribers table
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Enable RLS (Row Level Security)
ALTER TABLE paintings ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;

-- RLS Policies for paintings (public read)
CREATE POLICY "Paintings are viewable by everyone" ON paintings
  FOR SELECT USING (true);

-- RLS Policies for orders (users can only see their own orders)
CREATE POLICY "Users can view their own orders" ON orders
  FOR SELECT USING (auth.jwt() ->> 'email' = customer_email OR EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.email = auth.jwt() ->> 'email'
  ));

-- RLS Policies for order_items
CREATE POLICY "View order items" ON order_items
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM orders WHERE orders.id = order_items.order_id 
    AND (orders.customer_email = auth.jwt() ->> 'email' OR 
         EXISTS (SELECT 1 FROM admin_users WHERE admin_users.email = auth.jwt() ->> 'email'))
  ));

-- RLS Policies for newsletter_subscribers (authenticated only)
CREATE POLICY "Insert newsletter subscriptions" ON newsletter_subscribers
  FOR INSERT WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX idx_paintings_featured ON paintings(featured);
CREATE INDEX idx_paintings_category ON paintings(category);
CREATE INDEX idx_orders_customer_email ON orders(customer_email);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_order_items_order_id ON order_items(order_id);

-- Insert sample paintings
INSERT INTO paintings (title, description, price, image_url, category, width, height, medium, year, stock, featured)
VALUES
  (
    'Moonlit Dreams',
    'A serene landscape capturing the ethereal beauty of a moonlit night. Oil on canvas with rich, deep blues and silvers.',
    2500.00,
    '/images/sample-1.jpg',
    'Landscape',
    24,
    36,
    'Oil on Canvas',
    2024,
    1,
    true
  ),
  (
    'Urban Reflection',
    'Contemporary abstract piece exploring light and shadow in urban environments. Mixed media.',
    1800.00,
    '/images/sample-2.jpg',
    'Abstract',
    18,
    24,
    'Mixed Media',
    2024,
    1,
    true
  ),
  (
    'Whispers of Nature',
    'Botanical illustration series celebrating the intricate details of flora. Watercolor.',
    950.00,
    '/images/sample-3.jpg',
    'Botanical',
    16,
    20,
    'Watercolor',
    2023,
    2,
    false
  );
