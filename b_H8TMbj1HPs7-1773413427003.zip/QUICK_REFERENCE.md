# Quick Reference Card

## Start Here 🚀

```bash
npm install                    # 1. Install deps
cp .env.local.example .env    # 2. Create env file
# Add your Supabase & Stripe keys to .env
npm run dev                    # 3. Start server
```

## URLs

| Page | URL |
|------|-----|
| Homepage | http://localhost:3000 |
| Admin Login | http://localhost:3000/admin |
| Admin Dashboard | http://localhost:3000/admin/dashboard |
| Add Painting | http://localhost:3000/admin/add-painting |

## Default Login

```
Email: admin@bailaaart.com
Password: demo123456
```

## Environment Variables

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
ADMIN_PASSWORD=demo123456
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## Key Files

| File | Purpose |
|------|---------|
| `app/page.tsx` | Homepage |
| `app/admin/page.tsx` | Admin login |
| `app/admin/dashboard/page.tsx` | Admin panel |
| `lib/supabase.ts` | Database functions |
| `app/globals.css` | Styles & colors |

## Key Commands

```bash
npm run dev       # Start development
npm run build     # Build for production
npm run start     # Start production server
npm run lint      # Check code quality
```

## API Endpoints

```
GET    /api/paintings              # Get all paintings
POST   /api/paintings              # Add painting (admin)
PUT    /api/paintings/:id          # Update painting (admin)
DELETE /api/paintings/:id          # Delete painting (admin)
POST   /api/admin/login            # Login
POST   /api/create-checkout-session # Stripe checkout
POST   /api/subscribe              # Newsletter
```

## Database Tables

- `paintings` - Your artwork
- `orders` - Customer orders
- `order_items` - Items per order
- `admin_users` - Admin accounts
- `newsletter_subscribers` - Email list

## Stripe Test Card

```
Card Number: 4242 4242 4242 4242
Expiry: Any future date (12/25)
CVC: Any 3 digits (123)
```

## Deploy to Vercel

1. Push code to GitHub
2. Go to vercel.com → New Project
3. Select repository
4. Add environment variables
5. Click Deploy
6. Update GitHub actions (optional)

## Troubleshooting

**Module not found?**
```bash
rm -rf .next
npm run dev
```

**Database error?**
Check `.env` has correct Supabase URL/key

**Stripe error?**
Check `.env` has correct Stripe keys

**Admin login fails?**
- Email: `admin@bailaaart.com`
- Password: value of `ADMIN_PASSWORD` env var

## Customize

| Change | Location |
|--------|----------|
| Instagram handle | Search `@bailaa_art` |
| Admin password | `ADMIN_PASSWORD` env var |
| Primary color | `app/globals.css` |
| Admin email | `app/api/admin/login/route.ts` |

## Documentation

- **Full Setup**: See `SETUP_GUIDE.md`
- **Deploy**: See `DEPLOYMENT_CHECKLIST.md`
- **APIs**: See `API_REFERENCE.md`
- **Overview**: See `PROJECT_SUMMARY.md`

## File Structure Quick Look

```
app/                    Pages & routes
├── page.tsx           Homepage
├── admin/             Admin panel
├── paintings/         Painting details
├── cart/              Shopping cart
└── api/               API endpoints

components/            React components
lib/                   Utilities & DB
public/                Static files
```

## Next.js Features Used

- App Router (latest)
- Server Components
- API Routes
- Image Optimization
- Automatic deployments

## Important Notes

⚠️ **Before Production:**
- Change `ADMIN_PASSWORD`
- Update Instagram handle
- Verify Stripe is on live keys
- Test checkout completely
- Enable HTTPS (automatic on Vercel)

## Package Versions

- Next.js 16.1.6
- React 19.2.4
- Tailwind 4.2.0
- TypeScript 5.7.3

## Getting Help

1. Check documentation files
2. Review code comments
3. Check browser console for errors
4. Review Supabase/Stripe dashboards

## Remember

- Save `.env.local` (never commit!)
- Test admin flow before launch
- Backup environment variables
- Monitor Stripe transactions
- Keep dependencies updated

---

**Questions?** See README.md for full guide
**Ready to deploy?** See DEPLOYMENT_CHECKLIST.md
