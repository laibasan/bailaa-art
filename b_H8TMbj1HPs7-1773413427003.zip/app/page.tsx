import { getPaintings, getFeaturedPaintings } from '@/lib/supabase';
import { PaintingCard } from '@/components/painting-card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Instagram, Mail, ShoppingCart } from 'lucide-react';
import { Newsletter } from '@/components/newsletter';

export default async function Home() {
  const [featured, allPaintings] = await Promise.all([
    getFeaturedPaintings(),
    getPaintings(),
  ]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Navigation */}
      <nav className="border-b border-slate-800 sticky top-0 z-50 bg-slate-950/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center">
              <span className="text-white font-bold text-lg">BA</span>
            </div>
            <span className="font-bold text-xl text-white hidden sm:inline">Bailaa Art</span>
          </Link>
          <div className="flex items-center gap-4">
            <a
              href="https://instagram.com/bailaa_art"
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-emerald-400 transition-colors"
            >
              <Instagram size={20} />
            </a>
            <Link
              href="/cart"
              className="relative text-slate-400 hover:text-emerald-400 transition-colors"
            >
              <ShoppingCart size={20} />
            </Link>
            <Link
              href="/admin"
              className="text-sm px-3 py-2 rounded-lg bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition-colors"
            >
              Admin
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-slate-100 via-emerald-300 to-blue-300 bg-clip-text text-transparent">
          Contemporary Art by Bailaa
        </h1>
        <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
          Discover stunning original paintings that bring color and emotion to your space
        </p>
        <Link href="#gallery">
          <Button size="lg" className="bg-emerald-500 hover:bg-emerald-600 text-white">
            Explore Gallery
          </Button>
        </Link>
      </section>

      {/* Featured Section */}
      {featured.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 border-t border-slate-800">
          <h2 className="text-4xl font-bold mb-12 text-white">Featured Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featured.map((painting) => (
              <PaintingCard key={painting.id} painting={painting} />
            ))}
          </div>
        </section>
      )}

      {/* All Paintings Gallery */}
      <section
        id="gallery"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 border-t border-slate-800"
      >
        <h2 className="text-4xl font-bold mb-12 text-white">All Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {allPaintings.map((painting) => (
            <PaintingCard key={painting.id} painting={painting} />
          ))}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="border-t border-slate-800 py-16 bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Newsletter />
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-white mb-4">Bailaa Art</h3>
              <p className="text-slate-400 text-sm">
                Contemporary paintings crafted with passion and creativity
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li>
                  <Link href="#gallery" className="hover:text-emerald-400 transition-colors">
                    Gallery
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="hover:text-emerald-400 transition-colors">
                    About
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Follow</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a
                    href="https://instagram.com/bailaa_art"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-400 hover:text-emerald-400 transition-colors"
                  >
                    Instagram @bailaa_art
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Contact</h4>
              <a
                href="mailto:hello@bailaaart.com"
                className="text-slate-400 hover:text-emerald-400 transition-colors flex items-center gap-2"
              >
                <Mail size={16} />
                Get in Touch
              </a>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-sm text-slate-500">
            <p>&copy; 2024 Bailaa Art. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
