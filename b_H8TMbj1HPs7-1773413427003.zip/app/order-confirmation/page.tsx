'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { CheckCircle, ArrowRight } from 'lucide-react';

export default function OrderConfirmation() {
  const searchParams = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const [orderNumber, setOrderNumber] = useState('');

  useEffect(() => {
    if (sessionId) {
      // Generate an order number from the session ID
      const number = `ORD-${sessionId.substring(0, 8).toUpperCase()}-${Date.now().toString().slice(-4)}`;
      setOrderNumber(number);
      
      // Clear the cart
      localStorage.removeItem('cart');
    }
  }, [sessionId]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center px-4">
      <div className="w-full max-w-md text-center">
        {/* Success Icon */}
        <div className="flex justify-center mb-8">
          <CheckCircle className="text-emerald-400" size={80} />
        </div>

        {/* Title */}
        <h1 className="text-4xl font-bold text-white mb-4">
          Order Confirmed!
        </h1>

        <p className="text-slate-300 mb-8">
          Thank you for your purchase. We're excited to ship your beautiful artwork!
        </p>

        {/* Order Details */}
        {orderNumber && (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 mb-8">
            <p className="text-slate-400 text-sm mb-2">Order Number</p>
            <p className="text-xl font-bold text-emerald-400 font-mono">{orderNumber}</p>
          </div>
        )}

        {/* Message */}
        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-6 mb-8">
          <p className="text-emerald-400 text-sm">
            A confirmation email has been sent to your inbox with order details and shipping information.
          </p>
        </div>

        {/* Next Steps */}
        <div className="text-left mb-8">
          <h3 className="font-semibold text-white mb-4">Next Steps:</h3>
          <ul className="space-y-3 text-slate-300 text-sm">
            <li className="flex gap-3">
              <span className="text-emerald-400 font-bold">1</span>
              <span>Check your email for the order confirmation</span>
            </li>
            <li className="flex gap-3">
              <span className="text-emerald-400 font-bold">2</span>
              <span>We'll prepare your artwork with care</span>
            </li>
            <li className="flex gap-3">
              <span className="text-emerald-400 font-bold">3</span>
              <span>You'll receive tracking info via email</span>
            </li>
            <li className="flex gap-3">
              <span className="text-emerald-400 font-bold">4</span>
              <span>Enjoy your new piece of art!</span>
            </li>
          </ul>
        </div>

        {/* CTA Buttons */}
        <div className="space-y-3">
          <Link href="/" className="block">
            <Button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white">
              <ArrowRight size={20} className="mr-2" />
              Continue Shopping
            </Button>
          </Link>
          <a href="https://instagram.com/bailaa_art" target="_blank" rel="noopener noreferrer">
            <Button
              variant="outline"
              className="w-full border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
            >
              Follow us on Instagram
            </Button>
          </a>
        </div>

        {/* Support */}
        <div className="mt-8 pt-8 border-t border-slate-800 text-center">
          <p className="text-slate-400 text-sm mb-2">Questions about your order?</p>
          <a
            href="https://instagram.com/bailaa_art"
            target="_blank"
            rel="noopener noreferrer"
            className="text-emerald-400 hover:text-emerald-300 transition-colors text-sm"
          >
            DM us on Instagram @bailaa_art
          </a>
        </div>
      </div>
    </div>
  );
}
