import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import crypto from 'crypto';

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    // For demo purposes, use hardcoded credentials
    // In production, query database and verify password hash with bcrypt
    if (email === 'admin@bailaaart.com' && password === 'demo123456') {
      const token = crypto.randomBytes(32).toString('hex');
      
      return NextResponse.json(
        { token, message: 'Login successful' },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { error: 'Invalid email or password' },
      { status: 401 }
    );
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'Login failed' },
      { status: 500 }
    );
  }
}
