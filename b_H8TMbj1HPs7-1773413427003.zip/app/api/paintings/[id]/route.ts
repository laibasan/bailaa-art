import { supabase } from '@/lib/supabase';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { data: painting, error } = await supabase
      .from('paintings')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return NextResponse.json(painting);
  } catch (error) {
    console.error('Error fetching painting:', error);
    return NextResponse.json(
      { error: 'Failed to fetch painting' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = request.headers.get('Authorization')?.split(' ')[1];
    if (!token) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const data = await request.json();

    const { data: painting, error } = await supabase
      .from('paintings')
      .update({
        title: data.title,
        description: data.description,
        price: data.price,
        image_url: data.image_url,
        medium: data.medium,
        width: data.width,
        height: data.height,
        year: data.year,
        stock: data.stock,
        featured: data.featured,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return NextResponse.json(painting);
  } catch (error) {
    console.error('Error updating painting:', error);
    return NextResponse.json(
      { error: 'Failed to update painting' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = request.headers.get('Authorization')?.split(' ')[1];
    if (!token) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const { error } = await supabase
      .from('paintings')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting painting:', error);
    return NextResponse.json(
      { error: 'Failed to delete painting' },
      { status: 500 }
    );
  }
}
