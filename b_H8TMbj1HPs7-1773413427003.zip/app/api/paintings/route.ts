import { getPaintings } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';
import { NextRequest, NextResponse } from 'next/server';

export async function GET() {
  try {
    const paintings = await getPaintings();
    return NextResponse.json(paintings);
  } catch (error) {
    console.error('Error fetching paintings:', error);
    return NextResponse.json(
      { error: 'Failed to fetch paintings' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get('Authorization')?.split(' ')[1];
    if (!token) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const data = await request.json();

    const { data: painting, error } = await supabase
      .from('paintings')
      .insert([
        {
          title: data.title,
          description: data.description,
          price: data.price,
          image_url: data.image_url,
          medium: data.medium,
          width: data.width,
          height: data.height,
          year: data.year,
          stock: data.stock,
          featured: data.featured || false,
        },
      ])
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json(painting, { status: 201 });
  } catch (error) {
    console.error('Error creating painting:', error);
    return NextResponse.json(
      { error: 'Failed to create painting' },
      { status: 500 }
    );
  }
}
