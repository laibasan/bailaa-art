import { getPaintingById, getPaintings } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowLeft, ShoppingCart, Heart, Share2 } from 'lucide-react';
import { AddToCart } from '@/components/add-to-cart';

export async function generateStaticParams() {
  const paintings = await getPaintings();
  return paintings.map((painting) => ({
    id: painting.id,
  }));
}

export default async function PaintingDetail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const painting = await getPaintingById(id);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Navigation */}
      <nav className="border-b border-slate-800 sticky top-0 z-50 bg-slate-950/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <ArrowLeft size={20} className="text-slate-400" />
            <span className="text-white">Back to Gallery</span>
          </Link>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Image */}
          <div className="flex items-start justify-center">
            <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-slate-800">
              <Image
                src={painting.image_url}
                alt={painting.title}
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 50vw"
                priority
              />
            </div>
          </div>

          {/* Details */}
          <div className="flex flex-col justify-start space-y-6">
            <div>
              <h1 className="text-4xl lg:text-5xl font-bold text-white mb-4">
                {painting.title}
              </h1>
              {painting.year && (
                <p className="text-slate-400 mb-2">Year: {painting.year}</p>
              )}
              {painting.medium && (
                <p className="text-slate-400 mb-2">Medium: {painting.medium}</p>
              )}
              {painting.width && painting.height && (
                <p className="text-slate-400">
                  Dimensions: {painting.width}" × {painting.height}"
                </p>
              )}
            </div>

            {/* Price */}
            <div className="border-t border-b border-slate-800 py-6">
              <p className="text-slate-400 text-sm mb-2">Price</p>
              <p className="text-5xl font-bold text-emerald-400">
                ${painting.price.toFixed(2)}
              </p>
            </div>

            {/* Stock Status */}
            {painting.stock > 0 ? (
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                <p className="text-emerald-400 font-semibold">
                  ✓ In Stock ({painting.stock} available)
                </p>
              </div>
            ) : (
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                <p className="text-red-400 font-semibold">Currently Out of Stock</p>
              </div>
            )}

            {/* Description */}
            {painting.description && (
              <div className="space-y-2">
                <h3 className="text-lg font-semibold text-white">About this work</h3>
                <p className="text-slate-300 leading-relaxed">{painting.description}</p>
              </div>
            )}

            {/* Actions */}
            <div className="space-y-3 pt-6">
              {painting.stock > 0 ? (
                <AddToCart painting={painting} />
              ) : (
                <Button disabled className="w-full bg-slate-700 hover:bg-slate-700 text-slate-400">
                  Out of Stock
                </Button>
              )}
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <Heart size={20} className="mr-2" />
                  Save
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <Share2 size={20} className="mr-2" />
                  Share
                </Button>
              </div>
            </div>

            {/* Contact */}
            <div className="border-t border-slate-800 pt-6">
              <p className="text-slate-400 text-sm mb-4">
                Have questions about this artwork?
              </p>
              <a
                href="https://instagram.com/bailaa_art"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                DM on Instagram @bailaa_art
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
