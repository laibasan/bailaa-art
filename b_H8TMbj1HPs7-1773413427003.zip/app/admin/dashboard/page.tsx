'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { LogOut, Plus, Edit2, Trash2 } from 'lucide-react';
import { Painting, getPaintings } from '@/lib/supabase';
import Image from 'next/image';

export default function AdminDashboard() {
  const router = useRouter();
  const [paintings, setPaintings] = useState<Painting[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    image_url: '',
    category: 'painting',
    medium: '',
    year: new Date().getFullYear().toString(),
    width: '',
    height: '',
    stock: '1',
    featured: false,
  });

  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      router.push('/admin/login');
      return;
    }

    loadPaintings();
  }, [router]);

  const loadPaintings = async () => {
    try {
      const data = await getPaintings();
      setPaintings(data);
    } catch (error) {
      console.error('Error loading paintings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    router.push('/admin/login');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const method = editingId ? 'PUT' : 'POST';
      const endpoint = editingId ? `/api/admin/paintings/${editingId}` : '/api/admin/paintings';

      const response = await fetch(endpoint, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setShowForm(false);
        setEditingId(null);
        setFormData({
          title: '',
          description: '',
          price: '',
          image_url: '',
          category: 'painting',
          medium: '',
          year: new Date().getFullYear().toString(),
          width: '',
          height: '',
          stock: '1',
          featured: false,
        });
        loadPaintings();
      } else {
        alert('Error saving painting');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error saving painting');
    }
  };

  const handleEdit = (painting: Painting) => {
    setFormData({
      title: painting.title,
      description: painting.description || '',
      price: painting.price.toString(),
      image_url: painting.image_url,
      category: painting.category,
      medium: painting.medium || '',
      year: painting.year?.toString() || new Date().getFullYear().toString(),
      width: painting.width?.toString() || '',
      height: painting.height?.toString() || '',
      stock: painting.stock.toString(),
      featured: painting.featured,
    });
    setEditingId(painting.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this painting?')) return;

    try {
      const response = await fetch(`/api/admin/paintings/${id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
        },
      });

      if (response.ok) {
        loadPaintings();
      } else {
        alert('Error deleting painting');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error deleting painting');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <p className="text-white">Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Navigation */}
      <nav className="border-b border-slate-800 bg-slate-950/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <LogOut size={18} className="mr-2" />
            Logout
          </Button>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Add New Button */}
        {!showForm && (
          <div className="mb-8">
            <Button
              onClick={() => setShowForm(true)}
              className="bg-emerald-500 hover:bg-emerald-600 text-white"
            >
              <Plus size={20} className="mr-2" />
              Add New Painting
            </Button>
          </div>
        )}

        {/* Form */}
        {showForm && (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-8 mb-12">
            <h2 className="text-2xl font-bold text-white mb-6">
              {editingId ? 'Edit Painting' : 'Add New Painting'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Title</label>
                  <Input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Price</label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    required
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Image URL</label>
                  <Input
                    type="url"
                    value={formData.image_url}
                    onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    required
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Medium</label>
                  <Input
                    type="text"
                    value={formData.medium}
                    onChange={(e) => setFormData({ ...formData, medium: e.target.value })}
                    placeholder="Oil on Canvas"
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Year</label>
                  <Input
                    type="number"
                    value={formData.year}
                    onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Stock</label>
                  <Input
                    type="number"
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm text-slate-300 mb-2">Description</label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe the painting..."
                  className="bg-slate-800 border-slate-700 text-white"
                  rows={4}
                />
              </div>

              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.featured}
                    onChange={(e) => setFormData({ ...formData, featured: e.target.checked })}
                    className="w-4 h-4"
                  />
                  <span className="text-slate-300">Featured</span>
                </label>
              </div>

              <div className="flex gap-4">
                <Button type="submit" className="bg-emerald-500 hover:bg-emerald-600 text-white">
                  Save Painting
                </Button>
                <Button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    setEditingId(null);
                  }}
                  variant="outline"
                  className="border-slate-700 text-slate-400 hover:text-white"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </div>
        )}

        {/* Paintings List */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-6">Your Paintings</h2>
          {paintings.length === 0 ? (
            <p className="text-slate-400">No paintings yet. Add your first painting!</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {paintings.map((painting) => (
                <div
                  key={painting.id}
                  className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden"
                >
                  <div className="relative w-full h-48 bg-slate-800">
                    <Image
                      src={painting.image_url}
                      alt={painting.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="p-4 space-y-3">
                    <div>
                      <h3 className="font-semibold text-white">{painting.title}</h3>
                      <p className="text-emerald-400 font-bold">${painting.price.toFixed(2)}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleEdit(painting)}
                        size="sm"
                        variant="outline"
                        className="flex-1 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
                      >
                        <Edit2 size={16} className="mr-1" />
                        Edit
                      </Button>
                      <Button
                        onClick={() => handleDelete(painting.id)}
                        size="sm"
                        variant="outline"
                        className="flex-1 border-red-500/30 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                      >
                        <Trash2 size={16} className="mr-1" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
