'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { useRouter, useParams } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { Painting } from '@/lib/supabase';

export default function EditPaintingPage() {
  const router = useRouter();
  const params = useParams();
  const paintingId = params.id as string;

  const [formData, setFormData] = useState<Partial<Painting>>({
    title: '',
    description: '',
    price: 0,
    image_url: '',
    medium: '',
    width: 0,
    height: 0,
    year: new Date().getFullYear(),
    stock: 1,
    featured: false,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('admin-token');
    if (!token) {
      router.push('/admin');
      return;
    }
    setIsAuthenticated(true);
    loadPainting();
  }, [router, paintingId]);

  const loadPainting = async () => {
    try {
      const response = await fetch(`/api/paintings/${paintingId}`);
      const data = await response.json();
      setFormData(data);
    } catch (err) {
      setError('Failed to load painting');
      console.error('Error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as any;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : type === 'number' ? parseFloat(value) : value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setError('');

    try {
      const response = await fetch(`/api/paintings/${paintingId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('admin-token')}`,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        router.push('/admin/dashboard');
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to update painting');
      }
    } catch (err) {
      setError('Failed to update painting');
      console.error('Error:', err);
    } finally {
      setIsSaving(false);
    }
  };

  if (!isAuthenticated || isLoading) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link href="/admin/dashboard" className="flex items-center gap-2 text-slate-400 hover:text-white mb-8">
          <ArrowLeft size={20} />
          Back to Dashboard
        </Link>

        <Card className="bg-slate-900 border-slate-800 p-8">
          <h1 className="text-3xl font-bold text-white mb-8">Edit Painting</h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-red-400 text-sm">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Title *</label>
                <Input
                  type="text"
                  name="title"
                  value={formData.title || ''}
                  onChange={handleChange}
                  placeholder="Painting Title"
                  className="bg-slate-800 border-slate-700 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Price (USD) *</label>
                <Input
                  type="number"
                  name="price"
                  value={formData.price || ''}
                  onChange={handleChange}
                  placeholder="299.99"
                  step="0.01"
                  className="bg-slate-800 border-slate-700 text-white"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Image URL *</label>
              <Input
                type="url"
                name="image_url"
                value={formData.image_url || ''}
                onChange={handleChange}
                placeholder="https://example.com/image.jpg"
                className="bg-slate-800 border-slate-700 text-white"
                required
              />
              <p className="text-xs text-slate-500 mt-1">Use image URLs from Supabase Storage or external CDN</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Description</label>
              <Textarea
                name="description"
                value={formData.description || ''}
                onChange={handleChange}
                placeholder="Describe the painting, its inspiration, and details..."
                className="bg-slate-800 border-slate-700 text-white min-h-32"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Medium</label>
                <Input
                  type="text"
                  name="medium"
                  value={formData.medium || ''}
                  onChange={handleChange}
                  placeholder="Oil on Canvas"
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Year</label>
                <Input
                  type="number"
                  name="year"
                  value={formData.year || ''}
                  onChange={handleChange}
                  placeholder="2024"
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Width (inches)</label>
                <Input
                  type="number"
                  name="width"
                  value={formData.width || ''}
                  onChange={handleChange}
                  placeholder="24"
                  step="0.1"
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Height (inches)</label>
                <Input
                  type="number"
                  name="height"
                  value={formData.height || ''}
                  onChange={handleChange}
                  placeholder="36"
                  step="0.1"
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Stock</label>
                <Input
                  type="number"
                  name="stock"
                  value={formData.stock || ''}
                  onChange={handleChange}
                  placeholder="1"
                  className="bg-slate-800 border-slate-700 text-white"
                  required
                />
              </div>
            </div>

            <div className="flex items-center gap-3 border-t border-slate-800 pt-6">
              <input
                type="checkbox"
                id="featured"
                name="featured"
                checked={formData.featured || false}
                onChange={handleChange}
                className="w-4 h-4 rounded border-slate-700 bg-slate-800 text-emerald-500"
              />
              <label htmlFor="featured" className="text-sm font-medium text-slate-300">
                Feature this painting on the homepage
              </label>
            </div>

            <div className="flex gap-4 pt-6 border-t border-slate-800">
              <Button
                type="submit"
                disabled={isSaving}
                className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white"
              >
                {isSaving ? 'Saving...' : 'Save Changes'}
              </Button>
              <Link href="/admin/dashboard" className="flex-1">
                <Button
                  type="button"
                  variant="outline"
                  className="w-full border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  Cancel
                </Button>
              </Link>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
