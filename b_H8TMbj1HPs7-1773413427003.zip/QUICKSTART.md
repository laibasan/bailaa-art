# Quick Start - Bailaa Art Gallery

Your complete art e-commerce website is ready! Follow these steps to get up and running in minutes.

## 5-Minute Setup

### 1. Get Your API Keys (2 minutes)

**Supabase:**
- Go to https://supabase.com → New Project
- Copy URL and `anon key` from Settings → API

**Stripe:**
- Go to https://stripe.com → Developers → API Keys
- Copy Publishable and Secret keys

### 2. Configure Environment (1 minute)

Create `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=your_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_key
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_key
STRIPE_SECRET_KEY=your_secret
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 3. Install & Run (2 minutes)

```bash
pnpm install
pnpm dev
```

Visit: http://localhost:3000

## What You Have

### Customer-Facing
- **Home Page**: Beautiful gallery with featured paintings
- **Painting Detail**: Click any painting to see full details
- **Shopping Cart**: Add to cart, manage quantities
- **Stripe Checkout**: Secure payment processing
- **Order Confirmation**: Thank you page with order number
- **Newsletter**: Email signup on home page
- **Instagram Integration**: Link to @bailaa_art

### Admin Panel
- **URL**: http://localhost:3000/admin
- **Demo Login**: 
  - Email: `admin@bailaaart.com`
  - Password: `demo123456`
- **Features**:
  - Add new paintings (with image URL)
  - Edit existing paintings
  - Delete paintings
  - Mark as featured
  - Track inventory/stock

## File Structure Overview

```
Key Files You'll Edit:
├── /app/page.tsx                 ← Home page (customize Instagram handle)
├── /app/admin/page.tsx          ← Admin login
├── /app/admin/dashboard/page.tsx ← Manage paintings
├── /lib/supabase.ts             ← Supabase functions
└── SETUP.md                      ← Detailed setup guide
```

## Customize Your Site

### Change Your Name/Info
Edit `/app/page.tsx`:
- Search for "bailaa_art" → replace with your handle
- Search for "Bailaa Art" → replace with your name

### Change Colors
The site uses emerald green + slate grey. To customize:
- Find Tailwind classes like `bg-emerald-500`, `text-emerald-400`
- Replace with your colors (e.g., `bg-blue-500`)
- Update in: `page.tsx`, `painting-card.tsx`, `dashboard/page.tsx`

### Add Paintings
1. Go to http://localhost:3000/admin
2. Log in with demo credentials
3. Click "Add New Painting"
4. Fill in details (image can be external URL)
5. Click "Save Painting"

## Database

Your Supabase database has these tables:
- `paintings` - Your artwork (title, price, image, etc.)
- `orders` - Customer orders
- `order_items` - Items in each order
- `admin_users` - Admin accounts
- `newsletter_subscribers` - Email signups

All set with Row Level Security (RLS) for safety.

## Next Steps

1. **Add Your Paintings**
   - Use external image URLs or upload to Supabase Storage
   - Mark 3+ as "Featured" for home page showcase

2. **Configure Real Admin Account**
   - In Supabase, add your actual email to `admin_users` table
   - Update password in settings

3. **Test Checkout**
   - Use Stripe test card: `4242 4242 4242 4242`
   - Any future date, any CVV

4. **Deploy to Vercel**
   - Push to GitHub → Connect to Vercel → Deploy
   - Add env vars in Vercel settings
   - Your site goes live!

## Common Questions

**Can customers upload images?**
No, you (admin) upload image URLs. For Supabase Storage, add the integration and use URLs from there.

**How do I send customer emails?**
The order confirmation URL is set up. To add actual emails, use Supabase functions or integrate SendGrid/Resend.

**How do I change payment amounts?**
Prices are set per painting in the admin panel.

**Can I add shipping costs?**
The cart page has tax calculated as 10%. Modify `/app/cart/page.tsx` for shipping.

**What about mobile?**
Fully responsive! Tested on all screen sizes.

## Support

- Check `SETUP.md` for detailed guide
- Errors appear in browser console (F12)
- Visit [@bailaa_art](https://instagram.com/bailaa_art)

---

**You're all set!** Your art gallery is live at http://localhost:3000 🎨
