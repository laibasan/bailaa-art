# Deployment Checklist

Complete this checklist before going to production.

## Local Development

- [ ] Clone repository
- [ ] Run `npm install`
- [ ] Copy `.env.local.example` to `.env.local`
- [ ] Add Supabase credentials
- [ ] Add Stripe test credentials
- [ ] Run `npm run dev`
- [ ] Test homepage loads at `http://localhost:3000`
- [ ] Test admin login at `http://localhost:3000/admin`
- [ ] Add test painting via admin panel
- [ ] Test adding to cart and checkout flow

## Supabase Setup

- [ ] Create Supabase account at https://supabase.com
- [ ] Create new project
- [ ] Get URL and Anon Key from project settings
- [ ] Database tables auto-created (paintings, orders, order_items, admin_users, newsletter_subscribers)
- [ ] Configure Row Level Security if needed
- [ ] Set up Supabase Storage for painting images
- [ ] Create public bucket for images

## Stripe Setup

- [ ] Create Stripe account at https://stripe.com
- [ ] Get API keys from dashboard
- [ ] Use test keys for development
- [ ] Get webhook signing secret
- [ ] Test checkout with Stripe test card: `4242 4242 4242 4242`
- [ ] Configure webhook endpoint in Stripe dashboard

## GitHub Setup

- [ ] Initialize git: `git init`
- [ ] Add all files: `git add .`
- [ ] Make initial commit: `git commit -m "Initial commit"`
- [ ] Create GitHub repository
- [ ] Add remote: `git remote add origin <url>`
- [ ] Push: `git push -u origin main`

## Vercel Deployment

- [ ] Go to https://vercel.com
- [ ] Click "New Project"
- [ ] Import GitHub repository
- [ ] Set environment variables:
  - [ ] NEXT_PUBLIC_SUPABASE_URL
  - [ ] NEXT_PUBLIC_SUPABASE_ANON_KEY
  - [ ] NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY (use live key)
  - [ ] STRIPE_SECRET_KEY (use live key)
  - [ ] STRIPE_WEBHOOK_SECRET
  - [ ] ADMIN_PASSWORD (change from default!)
  - [ ] NEXT_PUBLIC_APP_URL (your production domain)
- [ ] Deploy
- [ ] Wait for deployment to complete
- [ ] Add custom domain if desired

## Post-Deployment

- [ ] Test production site loads
- [ ] Test admin login at `/admin`
- [ ] Test adding paintings
- [ ] Test checkout with Stripe live cards
- [ ] Configure Stripe webhook:
  - URL: `https://yourdomain.com/api/webhooks/stripe`
  - Events: checkout.session.completed, charge.refunded
- [ ] Verify order emails work
- [ ] Add production paintings with real images
- [ ] Test newsletter subscription
- [ ] Monitor Stripe dashboard for payments

## Customization Before Launch

- [ ] Change admin password from `demo123456`
- [ ] Update Instagram handle (@bailaa_art)
- [ ] Upload actual painting images
- [ ] Update painting titles, descriptions, prices
- [ ] Set featured paintings
- [ ] Update email contact address
- [ ] Update about/contact pages if needed
- [ ] Add legal pages (privacy, terms, shipping)

## Security Checklist

- [ ] Change default admin password
- [ ] Enable HTTPS (automatic with Vercel)
- [ ] Set secure environment variables
- [ ] Review Stripe security settings
- [ ] Test SQL injection prevention
- [ ] Verify CORS settings
- [ ] Check sensitive data isn't logged

## Performance Optimization

- [ ] Enable image optimization
- [ ] Test page load times
- [ ] Monitor database queries
- [ ] Set up analytics
- [ ] Enable caching where appropriate
- [ ] Test on slow connections

## Monitoring & Maintenance

- [ ] Set up error tracking (Sentry, etc.)
- [ ] Monitor Stripe transactions
- [ ] Regular database backups
- [ ] Check server logs regularly
- [ ] Update dependencies monthly
- [ ] Monitor uptime

## Go Live!

Once all items are checked:
1. Announce on Instagram
2. Share store link
3. Monitor for issues
4. Track sales/analytics
5. Gather customer feedback
6. Plan improvements

---

**Questions?** Reference SETUP_GUIDE.md or README.md
