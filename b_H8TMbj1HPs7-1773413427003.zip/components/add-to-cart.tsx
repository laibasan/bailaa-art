'use client';

import { Painting } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { ShoppingCart } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

interface AddToCartProps {
  painting: Painting;
}

export function AddToCart({ painting }: AddToCartProps) {
  const router = useRouter();
  const [isAdding, setIsAdding] = useState(false);

  const handleAddToCart = () => {
    setIsAdding(true);
    
    // Get existing cart
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    
    // Check if painting already in cart
    const existingItem = cart.find((item: any) => item.id === painting.id);
    
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({
        ...painting,
        quantity: 1,
      });
    }
    
    // Save updated cart
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Redirect to cart
    router.push('/cart');
  };

  return (
    <Button
      onClick={handleAddToCart}
      disabled={isAdding}
      className="w-full bg-emerald-500 hover:bg-emerald-600 text-white text-lg py-6"
    >
      <ShoppingCart size={20} className="mr-2" />
      {isAdding ? 'Adding...' : 'Add to Cart'}
    </Button>
  );
}
