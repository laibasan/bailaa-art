'use client';

import { Painting } from '@/lib/supabase';
import Image from 'next/image';
import Link from 'next/link';
import { Heart } from 'lucide-react';
import { useState } from 'react';

interface PaintingCardProps {
  painting: Painting;
}

export function PaintingCard({ painting }: PaintingCardProps) {
  const [isFavorited, setIsFavorited] = useState(false);

  return (
    <Link href={`/paintings/${painting.id}`}>
      <div className="group cursor-pointer">
        {/* Image Container */}
        <div className="relative h-80 w-full overflow-hidden rounded-lg bg-slate-800 mb-4 transition-transform duration-300 group-hover:scale-105">
          <Image
            src={painting.image_url}
            alt={painting.title}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          />
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center">
            <button
              onClick={(e) => {
                e.preventDefault();
                setIsFavorited(!isFavorited);
              }}
              className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-white/90 rounded-full p-3 hover:bg-white"
            >
              <Heart
                size={24}
                className={isFavorited ? 'fill-red-500 text-red-500' : 'text-slate-900'}
              />
            </button>
          </div>
        </div>

        {/* Details */}
        <div className="space-y-2">
          <h3 className="text-lg font-semibold text-slate-100 group-hover:text-white transition-colors">
            {painting.title}
          </h3>
          {painting.medium && (
            <p className="text-sm text-slate-400">{painting.medium}</p>
          )}
          <div className="flex items-center justify-between pt-2">
            <span className="text-2xl font-bold text-emerald-400">
              ${painting.price.toFixed(2)}
            </span>
            {painting.stock > 0 && (
              <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2 py-1 rounded">
                In Stock
              </span>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
