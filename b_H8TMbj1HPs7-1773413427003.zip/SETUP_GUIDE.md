# Bailaa Art - Painting E-Commerce Website

A sophisticated dark-themed art gallery and e-commerce platform for selling original paintings with an admin dashboard.

## Features

✨ **Customer Features:**
- Beautiful dark-themed gallery
- Individual painting detail pages
- Shopping cart functionality
- Stripe checkout integration
- Newsletter subscription
- Instagram integration (@bailaa_art)

🎨 **Admin Features:**
- Secure admin login dashboard
- Add/edit/delete paintings
- Manage painting inventory
- Mark paintings as featured
- Upload painting details (dimensions, medium, year)

## Tech Stack

- **Frontend**: Next.js 15, React 19, Tailwind CSS v4
- **Backend**: Next.js API Routes
- **Database**: Supabase (PostgreSQL)
- **Payments**: Stripe
- **Deployment**: Ready for Vercel

## Local Development Setup

### 1. Install Dependencies
```bash
npm install
# or
pnpm install
```

### 2. Environment Variables

Copy `.env.local.example` to `.env.local` and add your credentials:

```bash
cp .env.local.example .env.local
```

Then fill in the values:

```
# Supabase (get from https://supabase.com)
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# Stripe (get from https://stripe.com)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Admin
ADMIN_PASSWORD=demo123456

# App URL
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 3. Database Setup

1. Create a Supabase account at https://supabase.com
2. Create a new project
3. The database tables will be created when you run the migration
4. In Supabase SQL Editor, run the setup script:
   - Tables: paintings, orders, order_items, admin_users, newsletter_subscribers
   - Row Level Security policies are already configured

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Admin Dashboard Access

**Login URL**: [http://localhost:3000/admin](http://localhost:3000/admin)

**Demo Credentials:**
- Email: `admin@bailaaart.com`
- Password: `demo123456`

**Admin Dashboard Features:**
- View all paintings in grid layout
- Add new paintings with images, details, pricing
- Edit existing painting information
- Delete paintings
- Toggle featured status
- Manage inventory/stock

## Adding Paintings

1. Navigate to Admin Dashboard: `/admin`
2. Login with demo credentials
3. Click "Add Painting"
4. Fill in:
   - **Title**: Painting name
   - **Price**: USD price
   - **Image URL**: Direct link to painting image (use Supabase Storage or CDN)
   - **Description**: Painting details
   - **Medium**: e.g., "Oil on Canvas"
   - **Dimensions**: Width and height in inches
   - **Year**: Year created
   - **Stock**: Number available (typically 1 for originals)
   - **Featured**: Check to show on homepage

## Image Hosting

For production, upload images to Supabase Storage:

1. Go to Supabase Dashboard → Storage
2. Create a bucket called "paintings"
3. Upload your painting images
4. Use the public URL as the image_url

## Stripe Setup

1. Create a Stripe account at https://stripe.com
2. Get your API keys from Stripe Dashboard
3. Add to `.env.local`:
   - Publishable key (starts with `pk_`)
   - Secret key (starts with `sk_`)
4. Set up webhooks:
   - Endpoint: `https://yourdomain.com/api/webhooks/stripe`
   - Events: `checkout.session.completed`, `charge.refunded`

## Customization

### Colors & Branding

The site uses a dark theme with emerald accents. To customize:

1. Edit `app/globals.css` for design tokens
2. Update color values in components
3. Logo/branding in navigation (look for "BA" logo)

### Instagram Integration

Replace `@bailaa_art` with your Instagram handle in:
- `app/page.tsx` - Navigation and footer links
- `app/paintings/[id]/page.tsx` - Contact section

## Deployment to Vercel

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git push -u origin main
```

### 2. Deploy on Vercel

1. Visit https://vercel.com
2. Click "New Project"
3. Select your GitHub repository
4. Add environment variables from `.env.local`
5. Deploy!

### 3. Production Checklist

- [ ] Update admin password to something secure
- [ ] Add all environment variables in Vercel settings
- [ ] Configure Stripe webhook with production URL
- [ ] Test checkout with Stripe test cards
- [ ] Upload production images to Supabase
- [ ] Update Instagram handle
- [ ] Update contact email
- [ ] Configure custom domain

## Project Structure

```
app/
├── page.tsx                 # Homepage gallery
├── layout.tsx              # Root layout
├── cart/page.tsx           # Shopping cart
├── order-confirmation/     # Order success page
├── paintings/[id]/page.tsx # Individual painting detail
├── admin/                  # Admin section
│   ├── page.tsx           # Login page
│   ├── dashboard/         # Main admin dashboard
│   ├── add-painting/      # Add new painting
│   └── edit-painting/     # Edit existing painting
└── api/
    ├── paintings/         # Paintings CRUD API
    ├── create-checkout-session/ # Stripe checkout
    ├── webhooks/stripe/   # Stripe webhooks
    ├── subscribe/         # Newsletter subscription
    └── admin/login/       # Admin authentication

components/
├── newsletter.tsx         # Newsletter signup
├── painting-card.tsx      # Painting grid card
├── add-to-cart.tsx       # Add to cart button
└── theme-provider.tsx    # Theme setup

lib/
└── supabase.ts          # Supabase client & queries
```

## Database Schema

### paintings
- id (UUID)
- title, description, price, image_url
- medium, width, height, year
- stock, featured
- created_at, updated_at

### orders
- id, order_number
- customer_email, customer_name, customer_phone
- total_price, status
- stripe_payment_id
- shipping_* fields
- created_at, updated_at

### order_items
- id, order_id, painting_id
- quantity, price
- created_at

### newsletter_subscribers
- id, email, subscribed_at

### admin_users
- id, email, password_hash, created_at

## Troubleshooting

**"Module not found: Newsletter"**
- Ensure all files are saved
- Clear `.next` folder and restart dev server

**Supabase connection errors**
- Verify SUPABASE_URL and ANON_KEY in `.env.local`
- Check Supabase project is active

**Stripe errors**
- Verify API keys are correct
- Test with Stripe test card: `4242 4242 4242 4242`
- Check webhook secret matches

**Admin login fails**
- Verify email is `admin@bailaaart.com`
- Default password: `demo123456`
- Check ADMIN_PASSWORD in environment

## Support

For issues or questions:
- Instagram: @bailaa_art
- Check the troubleshooting section above
- Review Supabase, Stripe, and Next.js documentation

## License

© 2024 Bailaa Art. All rights reserved.
