import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseKey);

export interface Painting {
  id: string;
  title: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
  width?: number;
  height?: number;
  medium?: string;
  year?: number;
  stock: number;
  featured: boolean;
  created_at: string;
  updated_at: string;
}

export interface Order {
  id: string;
  order_number: string;
  customer_email: string;
  customer_name: string;
  customer_phone?: string;
  total_price: number;
  status: 'pending' | 'completed' | 'shipped' | 'cancelled';
  stripe_payment_id?: string;
  shipping_address?: string;
  shipping_city?: string;
  shipping_state?: string;
  shipping_zip?: string;
  shipping_country?: string;
  created_at: string;
  updated_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  painting_id: string;
  quantity: number;
  price: number;
  created_at: string;
}

// Paintings functions
export async function getPaintings() {
  const { data, error } = await supabase
    .from('paintings')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data as Painting[];
}

export async function getFeaturedPaintings() {
  const { data, error } = await supabase
    .from('paintings')
    .select('*')
    .eq('featured', true)
    .limit(6);
  
  if (error) throw error;
  return data as Painting[];
}

export async function getPaintingById(id: string) {
  const { data, error } = await supabase
    .from('paintings')
    .select('*')
    .eq('id', id)
    .single();
  
  if (error) throw error;
  return data as Painting;
}

// Orders functions
export async function createOrder(orderData: Omit<Order, 'id' | 'created_at' | 'updated_at'>) {
  const { data, error } = await supabase
    .from('orders')
    .insert([orderData])
    .select()
    .single();
  
  if (error) throw error;
  return data as Order;
}

export async function getOrderByNumber(orderNumber: string) {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('order_number', orderNumber)
    .single();
  
  if (error) throw error;
  return data as Order;
}

export async function updateOrderStatus(orderId: string, status: string) {
  const { data, error } = await supabase
    .from('orders')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', orderId)
    .select()
    .single();
  
  if (error) throw error;
  return data as Order;
}

// Order items functions
export async function addOrderItem(orderItem: Omit<OrderItem, 'id' | 'created_at'>) {
  const { data, error } = await supabase
    .from('order_items')
    .insert([orderItem])
    .select()
    .single();
  
  if (error) throw error;
  return data as OrderItem;
}

export async function getOrderItems(orderId: string) {
  const { data, error } = await supabase
    .from('order_items')
    .select('*')
    .eq('order_id', orderId);
  
  if (error) throw error;
  return data as OrderItem[];
}

// Newsletter functions
export async function subscribeNewsletter(email: string) {
  const { data, error } = await supabase
    .from('newsletter_subscribers')
    .insert([{ email }])
    .select()
    .single();
  
  if (error && error.code !== '23505') throw error; // 23505 is unique violation
  return data;
}
