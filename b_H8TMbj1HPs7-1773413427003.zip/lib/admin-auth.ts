import { supabase } from './supabase';

export async function verifyAdminPassword(email: string, password: string) {
  try {
    const { data, error } = await supabase
      .from('admin_users')
      .select('id, password_hash')
      .eq('email', email)
      .single();

    if (error || !data) {
      return null;
    }

    // For demo purposes, we'll do a simple string comparison
    // In production, use bcrypt to verify password hash
    const isValid = password === data.password_hash;

    if (isValid) {
      return data.id;
    }

    return null;
  } catch (error) {
    console.error('Auth error:', error);
    return null;
  }
}

export function setAdminSession(token: string) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('admin_token', token);
  }
}

export function getAdminSession() {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('admin_token');
  }
  return null;
}

export function clearAdminSession() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('admin_token');
  }
}

export function generateToken() {
  return Math.random().toString(36).substring(2, 15) +
    Math.random().toString(36).substring(2, 15);
}
