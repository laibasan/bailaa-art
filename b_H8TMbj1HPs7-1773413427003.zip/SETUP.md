# Bailaa Art - Setup Guide

Welcome to your art gallery e-commerce website! This guide will help you set up and run the project locally.

## Prerequisites

- Node.js 16+ and npm/pnpm
- A Supabase account (free tier available at supabase.com)
- A Stripe account (free tier available at stripe.com)

## Step 1: Environment Variables

Create a `.env.local` file in the project root with the following variables:

```
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
STRIPE_SECRET_KEY=your_stripe_secret_key

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### Getting Your Credentials

#### Supabase:
1. Go to [supabase.com](https://supabase.com) and create a new project
2. Navigate to Project Settings > API
3. Copy your `URL` and `anon key` (public key)
4. Paste them into `.env.local`

#### Stripe:
1. Go to [stripe.com](https://stripe.com) and create an account
2. Navigate to Developers > API Keys
3. Copy your `Publishable key` and `Secret key`
4. Paste them into `.env.local`

## Step 2: Install Dependencies

```bash
pnpm install
```

## Step 3: Database Setup

The database schema has already been created via migrations. If you need to manually create tables, you can:

1. Go to your Supabase project dashboard
2. Navigate to SQL Editor
3. Copy the SQL from `scripts/setup-database.sql` and paste it into the SQL Editor
4. Execute the query

To add sample paintings for testing:
1. Go to SQL Editor in Supabase
2. Copy the SQL from `scripts/seed-paintings.sql`
3. Execute it

## Step 4: Run the Development Server

```bash
pnpm dev
```

The app will be available at `http://localhost:3000`

## Features

### Customer Features
- 🎨 Beautiful gallery with painting cards
- 💳 Stripe checkout integration
- 🛒 Shopping cart system
- 📧 Newsletter subscription
- ⭐ Featured paintings section
- 📱 Fully responsive design

### Admin Dashboard
- **Login URL**: http://localhost:3000/admin

**Demo Credentials** (for testing):
- Email: `admin@bailaaart.com`
- Password: `demo123456`

#### Admin Functions:
- ➕ Add new paintings
- ✏️ Edit existing paintings
- 🗑️ Delete paintings
- 📌 Mark paintings as featured
- 📊 Manage inventory/stock

## Project Structure

```
/app
  ├── page.tsx                 # Home/Gallery page
  ├── cart/page.tsx           # Shopping cart
  ├── paintings/[id]/page.tsx  # Painting detail page
  ├── admin/
  │   ├── page.tsx           # Admin login
  │   └── dashboard/page.tsx  # Admin dashboard
  └── api/
      ├── subscribe/         # Newsletter API
      ├── create-checkout-session/  # Stripe checkout
      ├── webhooks/stripe/   # Stripe webhook
      └── admin/            # Admin CRUD APIs

/components
  ├── painting-card.tsx       # Gallery card component
  ├── add-to-cart.tsx        # Add to cart button
  └── newsletter.tsx         # Newsletter signup

/lib
  ├── supabase.ts            # Supabase client & functions
  └── admin-auth.ts          # Admin authentication utils
```

## Customization

### Update Your Information
- Gallery name: Edit in `/app/layout.tsx` (metadata.title)
- Instagram handle: Change `@bailaa_art` in `/app/page.tsx` and `/app/paintings/[id]/page.tsx`
- Colors: Modify Tailwind classes (currently using emerald and slate palette)
- Email: Update contact information in `/app/page.tsx`

### Add More Paintings
1. Go to http://localhost:3000/admin
2. Log in with demo credentials
3. Click "Add New Painting"
4. Fill in the details:
   - Title
   - Price
   - Image URL (external URL or upload to Supabase Storage)
   - Medium (e.g., "Oil on Canvas")
   - Year
   - Stock quantity
   - Description
   - Mark as Featured if desired
5. Click "Save Painting"

### Connect Your Stripe Webhook
To handle successful payments:

1. In Stripe Dashboard, go to Developers > Webhooks
2. Click "Add an endpoint"
3. Enter your URL: `https://yourdomain.com/api/webhooks/stripe`
4. Select events: `checkout.session.completed`
5. Add endpoint and copy the signing secret
6. Add to `.env.local`: `STRIPE_WEBHOOK_SECRET=your_signing_secret`

## Deploying to Vercel

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project" and select your repository
4. Add environment variables in Settings > Environment Variables
5. Deploy!

## Troubleshooting

### "Failed to fetch paintings"
- Check that your Supabase credentials are correct
- Make sure the database tables exist
- Verify you've created at least one painting in the admin panel

### "Stripe checkout fails"
- Verify your Stripe keys are correct
- Make sure you're in test mode (not live mode)
- Check browser console for detailed error messages

### "Admin login not working"
- Demo credentials are: `admin@bailaaart.com` / `demo123456`
- Check browser console for any errors
- Clear localStorage and try again

## Support

For issues or questions:
1. Check the browser console (F12) for error messages
2. Review Supabase and Stripe logs in their dashboards
3. Visit [@bailaa_art](https://instagram.com/bailaa_art) on Instagram

---

Happy selling! 🎨
