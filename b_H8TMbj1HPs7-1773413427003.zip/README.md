# Bailaa Art - Contemporary Paintings Store

A modern, dark-themed e-commerce platform for selling original paintings with a complete admin dashboard.

## Quick Start

### 1. Clone & Install
```bash
npm install
# or
pnpm install
```

### 2. Setup Environment Variables
```bash
cp .env.local.example .env.local
```

Add your credentials to `.env.local`:
- Supabase URL & Key
- Stripe API Keys
- Admin Password

### 3. Run Locally
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

### 4. Access Admin
- URL: [http://localhost:3000/admin](http://localhost:3000/admin)
- Email: `admin@bailaaart.com`
- Password: `demo123456`

## Key Features

**🎨 Customer Experience**
- Stunning dark gallery with featured paintings
- Individual artwork detail pages
- Shopping cart with Stripe checkout
- Newsletter subscription
- Instagram integration

**🛠 Admin Dashboard**
- Secure login system
- Add/edit/delete paintings
- Manage inventory and pricing
- Mark paintings as featured
- Full CRUD operations

## Tech Stack

- **Framework**: Next.js 15
- **UI**: React 19 + Tailwind CSS v4
- **Database**: Supabase (PostgreSQL)
- **Payments**: Stripe
- **Components**: shadcn/ui

## Project Structure

```
app/
├── page.tsx                    # Home gallery
├── paintings/[id]/page.tsx     # Painting details
├── cart/page.tsx               # Shopping cart
├── order-confirmation/page.tsx # Success page
└── admin/                      # Admin panel
    ├── page.tsx               # Login
    ├── dashboard/page.tsx     # Dashboard
    ├── add-painting/page.tsx  # Add painting
    └── edit-painting/[id]/page.tsx

api/
├── paintings/                 # Paintings CRUD
├── create-checkout-session/  # Stripe checkout
├── webhooks/stripe/          # Stripe webhooks
├── subscribe/                # Newsletter
└── admin/login/              # Admin auth

components/
├── painting-card.tsx
├── newsletter.tsx
├── add-to-cart.tsx
└── ui/                       # shadcn components
```

## Environment Variables

Create `.env.local`:

```env
# Supabase (https://supabase.com)
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=

# Stripe (https://stripe.com)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=

# Admin
ADMIN_PASSWORD=demo123456

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## Customization

- **Logo**: Update in `/app/page.tsx` navigation
- **Colors**: Edit `/app/globals.css` design tokens
- **Instagram**: Replace `@bailaa_art` with your handle
- **Password**: Change `ADMIN_PASSWORD` in `.env.local`

## Deployment

### Deploy to Vercel
1. Push to GitHub
2. Import project in Vercel
3. Add environment variables
4. Deploy

Learn more: [Vercel Deployment Docs](https://vercel.com/docs)

## Documentation

For detailed setup and customization guide, see [SETUP_GUIDE.md](./SETUP_GUIDE.md)

## Database Tables

- **paintings** - Artwork inventory
- **orders** - Customer orders
- **order_items** - Line items per order
- **admin_users** - Admin accounts
- **newsletter_subscribers** - Email subscribers

## Support

Instagram: [@bailaa_art](https://instagram.com/bailaa_art)

---

Built with Next.js • Powered by Supabase & Stripe
