# API Reference

Complete API documentation for Bailaa Art.

## Base URL
```
http://localhost:3000/api
https://yourdomain.com/api (production)
```

## Authentication
Admin endpoints require Bearer token in Authorization header:
```
Authorization: Bearer <admin_token>
```

---

## Paintings

### Get All Paintings
```
GET /paintings
```

**Response:**
```json
[
  {
    "id": "uuid",
    "title": "Painting Title",
    "description": "Description",
    "price": 299.99,
    "image_url": "https://...",
    "medium": "Oil on Canvas",
    "width": 24,
    "height": 36,
    "year": 2024,
    "stock": 1,
    "featured": true,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z"
  }
]
```

### Get Single Painting
```
GET /paintings/:id
```

### Create Painting
```
POST /paintings
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "New Painting",
  "description": "Description",
  "price": 299.99,
  "image_url": "https://...",
  "medium": "Oil on Canvas",
  "width": 24,
  "height": 36,
  "year": 2024,
  "stock": 1,
  "featured": false
}
```

**Response:** 201 Created
```json
{
  "id": "new-uuid",
  ...
}
```

### Update Painting
```
PUT /paintings/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "Updated Title",
  "price": 350.00,
  ...
}
```

**Response:** 200 OK

### Delete Painting
```
DELETE /paintings/:id
Authorization: Bearer <token>
```

**Response:** 200 OK
```json
{ "success": true }
```

---

## Admin Authentication

### Login
```
POST /admin/login
Content-Type: application/json

{
  "email": "admin@bailaaart.com",
  "password": "demo123456"
}
```

**Response:** 200 OK
```json
{
  "token": "auth-token",
  "email": "admin@bailaaart.com"
}
```

**Store token in localStorage:**
```javascript
localStorage.setItem('admin-token', data.token);
```

---

## Payments

### Create Checkout Session
```
POST /create-checkout-session
Content-Type: application/json

{
  "items": [
    {
      "id": "painting-uuid",
      "title": "Painting Name",
      "price": 299.99,
      "image_url": "https://...",
      "quantity": 1
    }
  ],
  "customerEmail": "buyer@example.com",
  "customerName": "Customer Name"
}
```

**Response:** 200 OK
```json
{
  "sessionId": "cs_test_..."
}
```

### Stripe Webhook Events
```
POST /webhooks/stripe
```

**Events handled:**
- `checkout.session.completed` - Payment successful
- `charge.refunded` - Refund processed

---

## Newsletter

### Subscribe
```
POST /subscribe
Content-Type: application/json

{
  "email": "subscriber@example.com"
}
```

**Response:** 200 OK
```json
{
  "message": "Subscribed successfully"
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "error": "Invalid request data"
}
```

### 401 Unauthorized
```json
{
  "error": "Unauthorized - token required"
}
```

### 404 Not Found
```json
{
  "error": "Resource not found"
}
```

### 500 Server Error
```json
{
  "error": "Server error message"
}
```

---

## Code Examples

### JavaScript/Fetch

**Get Paintings:**
```javascript
const response = await fetch('/api/paintings');
const paintings = await response.json();
```

**Admin Login:**
```javascript
const response = await fetch('/api/admin/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'admin@bailaaart.com',
    password: 'demo123456'
  })
});
const { token } = await response.json();
localStorage.setItem('admin-token', token);
```

**Add Painting (Admin):**
```javascript
const token = localStorage.getItem('admin-token');
const response = await fetch('/api/paintings', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify({
    title: 'New Painting',
    price: 299.99,
    image_url: 'https://...',
    stock: 1,
    featured: false
  })
});
```

**Checkout:**
```javascript
const response = await fetch('/api/create-checkout-session', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    items: cartItems,
    customerEmail: 'buyer@example.com',
    customerName: 'Customer Name'
  })
});
const { sessionId } = await response.json();
const stripe = await loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY);
await stripe.redirectToCheckout({ sessionId });
```

---

## Rate Limiting

Currently no rate limiting is implemented. Consider adding:
- 10 requests/minute for public endpoints
- 5 requests/minute for auth endpoints
- Implement using middleware or Vercel KV

---

## CORS

Endpoints are configured to work with same-origin requests. For cross-origin requests, CORS headers are set appropriately.

---

## Status Codes

| Code | Meaning |
|------|---------|
| 200 | OK - Request successful |
| 201 | Created - Resource created |
| 400 | Bad Request - Invalid parameters |
| 401 | Unauthorized - Authentication required |
| 404 | Not Found - Resource doesn't exist |
| 500 | Server Error - Something went wrong |

---

## Testing with cURL

```bash
# Get paintings
curl http://localhost:3000/api/paintings

# Login
curl -X POST http://localhost:3000/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@bailaaart.com","password":"demo123456"}'

# Subscribe to newsletter
curl -X POST http://localhost:3000/api/subscribe \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com"}'
```

---

## WebHooks

### Stripe Webhook Setup

1. Go to https://dashboard.stripe.com/webhooks
2. Click "Add endpoint"
3. Enter: `https://yourdomain.com/api/webhooks/stripe`
4. Select events:
   - `checkout.session.completed`
   - `charge.refunded`
5. Copy signing secret to `.env.local` as `STRIPE_WEBHOOK_SECRET`

---

**Last Updated:** 2024
**Version:** 1.0
